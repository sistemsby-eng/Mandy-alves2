# Mandy Alves — página de redirecionamento para Telegram

## Publicar na Vercel
1. Extraia o ZIP.
2. Entre em https://vercel.com/ e faça login.
3. Escolha **Add New → Project** e importe um repositório Git com estes arquivos, ou use a opção de deploy pela CLI.
4. Como é um site estático, não precisa de build command. A pasta raiz contém `index.html`.
5. Depois do deploy, copie o domínio `.vercel.app` e coloque esse endereço na bio do TikTok.

O botão leva para: https://t.me/Mandyyalvss_bot

## Personalização
- Edite `index.html` para alterar o texto, cores ou nome.
- Para colocar uma foto da modelo, substitua o bloco `<div class="avatar"...>` por uma tag `<img>` e adicione a imagem ao projeto.
